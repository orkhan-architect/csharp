﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exam_lab
{
    public class Users
    {
        public string? NSP { get; set; }
        public DateTime Birthdate { get; set; }
        public string? Login { get; set; }
        public string? Password { get; set; }
        public string? Slogan { get; set; }
        public bool inSession { get; set; } = false;
        public bool isAdmin { get; set; } = false;

        public Users() { }

        private static string HashString(string text, string salt = "")
        {
            if (String.IsNullOrEmpty(text))
            {
                return String.Empty;
            }

            // Uses SHA256 to create the hash
            using (var sha = new System.Security.Cryptography.SHA256Managed())
            {
                // Convert the string to a byte array first, to be processed
                byte[] textBytes = System.Text.Encoding.UTF8.GetBytes(text + salt);
                byte[] hashBytes = sha.ComputeHash(textBytes);

                // Convert back to a string, removing the '-' that BitConverter adds
                string hash = BitConverter
                    .ToString(hashBytes)
                    .Replace("-", String.Empty);

                return hash;
            }
        }

        private void FS_out()
        {
            string user_path = Login + "/user.xml";

            Users user = new();
            user.NSP = NSP;
            user.Birthdate = Birthdate;
            user.Login = Login;
            user.Password = Password;
            user.Slogan = Slogan;
            user.isAdmin = isAdmin;

            XmlSerializer xmlFormat = new XmlSerializer(typeof(Users));

            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, user);
            }
            Console.WriteLine("Userfile was created/edited successfully.\n");
        }

        private void FS_out(Users temp_user)
        {
            string user_path = temp_user.Login + "/user.xml";

            XmlSerializer xmlFormat = new XmlSerializer(typeof(Users));

            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, temp_user);
            }
            Console.WriteLine("Userfile was created/edited successfully.\n");
        }

        private Users FS_in(string temp_login)
        {
            string user_path = temp_login + "/user.xml";

            Users? user;

            if (Directory.Exists(temp_login))
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(Users));

                using (Stream fStream = File.OpenRead(user_path))
                {
                    user = (Users)xmlFormat.Deserialize(fStream);
                }
            }
            else
            {
                user = new Users();
            }

            return user;
        }

        public void Registration()
        {
            Console.Write("Enter your name surname patronymic -> ");
            NSP = Console.ReadLine();
            if (NSP != null)
                NSP = NSP.ToUpper();

            Console.Write("Enter your birthdate in format DD/MM/YYYY -> ");
            string? tmp_date = Console.ReadLine();
            if (tmp_date != null)
                Birthdate = Convert.ToDateTime(tmp_date);

            Console.Write("Enter your login name (FIN code of passport) -> ");
            Login = Console.ReadLine();
            if (Login != null)
                Login = Login.ToUpper();

            Console.Write("Enter your password -> ");
            Password = Console.ReadLine();
            if (Password != null)
                Password = HashString(Password, "cba");

            Console.Write("Enter your secret word for password recovery -> ");
            Slogan = Console.ReadLine();
            if (Slogan != null)
            {
                Slogan = Slogan.ToUpper();
                Slogan = HashString(Slogan, "abc");
            }

            if(Login == "23C9KNM")
            {
                isAdmin = true; // creating admin user
            }

            if (!Directory.Exists(Login))
            {
                if (Login != null)
                {
                    Directory.CreateDirectory(Login);
                    Console.WriteLine("\nDirectory was successfully created.");
                    FS_out();
                }
            }
            else
            {
                Console.WriteLine("\nThis login name exists in our system.");
            }
        }

        public void Edit_nsp()
        {
            Console.Write("Edit your name surname patronymic -> ");
            NSP = Console.ReadLine();
            if (NSP != null)
                NSP = NSP.ToUpper();

            FS_out();
        }

        public void Edit_birthdate()
        {
            Console.Write("Edit your birthdate in format DD/MM/YYYY -> ");
            string? tmp_date = Console.ReadLine();
            if (tmp_date != null)
                Birthdate = Convert.ToDateTime(tmp_date);

            FS_out();
        }

        public void Edit_pass()
        {
            Console.Write("Edit your password -> ");
            Password = Console.ReadLine();
            if (Password != null)
                Password = HashString(Password, "cba");

            FS_out();
            Console.Write("You have changed your password. Go and login again");
            return;
        }

        public void Pass_recovery()
        {
            string? tmp_login;
            Console.Write("Enter your login name (FIN code of passport) for recovery -> ");
            tmp_login = Console.ReadLine();
            if (tmp_login != null)
                tmp_login = tmp_login.ToUpper();

            string? tmp_slogan;
            Console.Write("Enter your secret word that you registered by before -> ");
            tmp_slogan = Console.ReadLine();
            if (tmp_slogan != null)
            {
                tmp_slogan = tmp_slogan.ToUpper();
                tmp_slogan = HashString(tmp_slogan, "abc");
            }

            Users tmp_user = FS_in(tmp_login);

            if (Directory.Exists(tmp_login))
            {
                if (tmp_user.Slogan.CompareTo(tmp_slogan) == 0)
                {
                    Console.Write("Edit your password -> ");
                    tmp_user.Password = Console.ReadLine();
                    if (tmp_user.Password != null)
                        tmp_user.Password = HashString(tmp_user.Password, "cba");

                    FS_out(tmp_user);
                }
                else
                {
                    Console.WriteLine("Your secret word is false");
                }
            }
            else
            {
                Console.WriteLine("There is no such user that you want recover password");
            }
        }

        public void Login_operation()
        {
            string? tmp_login;
            Console.Write("Enter your login name (FIN code of passport) -> ");
            tmp_login = Console.ReadLine();
            if (tmp_login != null)
                tmp_login = tmp_login.ToUpper();

            string? tmp_pass;
            Console.Write("Enter your password -> ");
            tmp_pass = Console.ReadLine();
            if (tmp_pass != null)
                tmp_pass = HashString(tmp_pass, "cba");

            Users tmp_user = FS_in(tmp_login);

            if (tmp_user.NSP != null)
            {
                if ((tmp_user.Password).CompareTo(tmp_pass) == 0)
                {
                    this.NSP = tmp_user.NSP;
                    this.Birthdate = tmp_user.Birthdate;
                    this.Login = tmp_user.Login;
                    this.Password = tmp_user.Password;
                    this.Slogan = tmp_user.Slogan;
                    this.isAdmin = tmp_user.isAdmin;
                    this.inSession = true;
                    Console.WriteLine("Welcome Mr/Mrs " + NSP);
                }
                else
                {
                    Console.WriteLine("Your password is false");
                }
            }
            else
            {
                Console.WriteLine("There is no such user that you want login");
            }
        }
    }

    public class Test
    {
        public string[]? Options { get; set; }
        public int ID { get; set; }
        public string? Question { get; set; }
        public string? Answer { get; set; }
        public float Score { get; set; }
        public byte Level { get; set; }

        public Test() { }

        private static string HashString(string text, string salt = "")
        {
            if (String.IsNullOrEmpty(text))
            {
                return String.Empty;
            }

            // Uses SHA256 to create the hash
            using (var sha = new System.Security.Cryptography.SHA256Managed())
            {
                // Convert the string to a byte array first, to be processed
                byte[] textBytes = System.Text.Encoding.UTF8.GetBytes(text + salt);
                byte[] hashBytes = sha.ComputeHash(textBytes);

                // Convert back to a string, removing the '-' that BitConverter adds
                string hash = BitConverter
                    .ToString(hashBytes)
                    .Replace("-", String.Empty);

                return hash;
            }
        }

        public void CreateTest(int ID)
        {
            this.ID = ID;

            Console.WriteLine("Enter the question");
            Question = Console.ReadLine();

            int options_size = 4; // you can give size to your options count
            Options = new string[options_size];
            Console.WriteLine("Enter 4 options for question by entering");
            for (int i = 0; i < options_size; i++)
                Options[i] = Console.ReadLine();

            Console.WriteLine("Enter the answer for question");
            Answer = Console.ReadLine();
            if (Answer != null)
            {
                Answer = Answer.ToUpper();
                Answer = HashString(Answer, "abc");
            }

            Console.WriteLine("Enter the score for question");
            Score = Convert.ToSingle(Console.ReadLine());

            Console.WriteLine("Enter the level for question");
            Level = Convert.ToByte(Console.ReadLine());
        }

        public void EditTest(Test AnyTest)
        {
            byte test_operation = 0;

            Console.WriteLine(
                    "What will you edit \n" +
                    "1. Question \n" +
                    "2. Score \n" +
                    "3. Level \n" +
                    "4. EXIT"
                    );

            test_operation = Convert.ToByte(Console.ReadLine());

            if (test_operation == 1)
            {
                Console.WriteLine("Edit the question");
                AnyTest.Question = Console.ReadLine();

                AnyTest.Options = new string[4];
                Console.WriteLine("Enter 4 options for new question");
                for (int i = 0; i < 4; i++)
                    AnyTest.Options[i] = Console.ReadLine();

                Console.WriteLine("Enter the answer for new question");
                AnyTest.Answer = Console.ReadLine();
                if (AnyTest.Answer != null)
                {
                    AnyTest.Answer = AnyTest.Answer.ToUpper();
                    AnyTest.Answer = HashString(AnyTest.Answer, "abc");
                }
            }
            else if(test_operation == 2)
            {
                Console.WriteLine("Edit the score for question");
                AnyTest.Score = Convert.ToSingle(Console.ReadLine());
            }
            else if(test_operation == 3)
            {
                Console.WriteLine("Enter the level for question");
                AnyTest.Level = Convert.ToByte(Console.ReadLine());
            }
            else
            {
                Console.WriteLine("You did not change anything");
            }
        }

        public override string ToString()
        {
            StringBuilder tmp_opt = new StringBuilder();
            for (int i = 0; i < 4; i++)
            {
                tmp_opt = tmp_opt.Append(Options[i]);
                tmp_opt = tmp_opt.AppendLine();
            }
            
            return
                $"\nLEVEL[{Level}] {Score} point\n" +
                $"#{ID}. {Question}\n" +
                $"{tmp_opt}";
        }
    }

    public class Subject
    {
        public List<string>? Subjects { get; set; }
        public Test[]? Tests { get; set; }
        public const int tests_size = 5; // you can give size to your tests count

        public Subject() { }

        private void FS_out(Test[] temp_tests, string subject)
        {
            string user_path = subject + ".xml";

            XmlSerializer xmlFormat = new XmlSerializer(typeof(Test[]));

            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, temp_tests);
            }
            Console.WriteLine("Test collection file was created/edited successfully.\n");
        }

        private void FS_out(List<string> tmp_subjects)
        {
            string user_path = "subjects.xml";

            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<string>));

            using (Stream fStream = File.Create(user_path))
            {
                xmlFormat.Serialize(fStream, tmp_subjects);
            }
        }

        public Test[] FS_in(string subject)
        {
            string user_path = subject + ".xml";

            Test[] tmp;

            XmlSerializer xmlFormat = new XmlSerializer(typeof(Test[]));

            using (Stream fStream = File.OpenRead(user_path))
            {
                tmp = (Test[])xmlFormat.Deserialize(fStream);
            }

            return tmp;
        }

        public List<string> FS_in()
        {
            string user_path = "subjects.xml";

            List<string> tmp_subjects;

            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<string>));

            using (Stream fStream = File.OpenRead(user_path))
            {
                tmp_subjects = (List<string>)xmlFormat.Deserialize(fStream);
            }

            return tmp_subjects;
        }

        public void Tests_creating()
        {
            Tests = new Test[tests_size];
            Test tmp;

            Console.WriteLine("Enter the subject that you want create tests");
            string? subject = Console.ReadLine();
            if (subject != null)
                subject = subject.ToUpper();

            string user_path = "subjects.xml";
            if (File.Exists(user_path))
            {
                Subjects = FS_in();

                for (int i = 0; i < Subjects.Count; i++)
                {
                    if (subject.CompareTo(Subjects[i]) != 0 && i == Subjects.Count - 1)
                    {
                        Subjects.Add(subject);
                        FS_out(Subjects);

                        for (int j = 0; j < tests_size; j++)
                        {
                            tmp = new Test();
                            tmp.CreateTest(j + 1);
                            Tests[j] = tmp;
                        }

                        FS_out(Tests, subject);
                    }
                    else if (subject.CompareTo(Subjects[i]) == 0)
                    {
                        Console.WriteLine("trying create existing subject");
                        break;
                    }
                }
            }
            else
            {
                Subjects = new List<string>();
                Subjects.Add(subject);
                FS_out(Subjects);

                for (int j = 0; j < tests_size; j++)
                {
                    tmp = new Test();
                    tmp.CreateTest(j + 1);
                    Tests[j] = tmp;
                }

                FS_out(Tests, subject);
            }
        }

        public void Tests_mixing()
        {
            Subjects = FS_in();

            int tests_per_subject = tests_size / Subjects.Count;
            int tests_last_subject = tests_per_subject + (tests_size % Subjects.Count);

            Tests = new Test[tests_size];
            Test[] tmp_tests;
            int test_index = 0;

            Random rand = new Random();
            byte random_index;

            for (int i = 0; i < Subjects.Count; i++)
            {
                tmp_tests = FS_in(Subjects[i]);

                if (tests_size % Subjects.Count == 0)
                {
                    for (int j = 0; j < tests_per_subject; j++)
                    {
                        random_index = Convert.ToByte(rand.Next(0, tests_size -1));
                        Tests[test_index] = tmp_tests[random_index];
                        test_index++;
                    }
                }
                else
                {
                    if (i == Subjects.Count - 1)
                    {
                        for (int j = 0; j < tests_last_subject; j++)
                        {
                            random_index = Convert.ToByte(rand.Next(0, tests_size - 1));
                            Tests[test_index] = tmp_tests[random_index];
                            test_index++;
                        }
                    }
                    else
                    {
                        for (int j = 0; j < tests_per_subject; j++)
                        {
                            random_index = Convert.ToByte(rand.Next(0, tests_size - 1));
                            Tests[test_index] = tmp_tests[random_index];
                            test_index++;
                        }
                    }
                }
            }

            FS_out(Tests, "MIXED");
        }

        public void Tests_editing()
        {
            Console.WriteLine("Enter the subject that you want edit tests");
            string? subject = Console.ReadLine();
            if (subject != null)
                subject = subject.ToUpper();

            Console.WriteLine("Enter the id_number of the test that you want edit");
            int test_id = Convert.ToInt32(Console.ReadLine());

            if (subject != null)
                subject = subject.ToUpper();

            Tests = FS_in(subject);

            Tests[test_id].EditTest(Tests[test_id]);

            FS_out(Tests, subject);
        }
    }

    public class Rating
    {
        public int Rank { get; set; }
        public string? Login { get; set; }
        public string? NSP { get; set; }
        public float Result { get; set; }
        public byte Right { get; set; }
        public DateTime ExamDate { get; set; }

        public Rating() { }

        public void SetRate(int Rank, string Login, string NSP, float Result, byte Right, DateTime ExamDate)
        {
            this.Rank = Rank;
            this.Login = Login;
            this.NSP = NSP;
            this.Result = Result;
            this.Right = Right;
            this.ExamDate = ExamDate;
        }

        public override string ToString()
        {
            return
                $"\n|{Rank}|\t|{Login}|\t|{NSP}|\t|{Result}|\t\t|{Right}|\t\t|{ExamDate}|\n";
        }
    }

    public class Quiz
    {
        public Users? user;
        public Subject? subject;
        public List<Rating>? general;
        public List<Rating>? special;

        public Quiz() { }

        private static string HashString(string text, string salt = "")
        {
            if (String.IsNullOrEmpty(text))
            {
                return String.Empty;
            }

            // Uses SHA256 to create the hash
            using (var sha = new System.Security.Cryptography.SHA256Managed())
            {
                // Convert the string to a byte array first, to be processed
                byte[] textBytes = System.Text.Encoding.UTF8.GetBytes(text + salt);
                byte[] hashBytes = sha.ComputeHash(textBytes);

                // Convert back to a string, removing the '-' that BitConverter adds
                string hash = BitConverter
                    .ToString(hashBytes)
                    .Replace("-", String.Empty);

                return hash;
            }
        }

        private void FS_out(List<Rating> temp_rate, string path)
        {
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Rating>));

            using (Stream fStream = File.Create(path))
            {
                xmlFormat.Serialize(fStream, temp_rate);
            }
            Console.WriteLine("Rating file was created/edited successfully.\n");
        }

        private List<Rating> FS_in(string path)
        {
            List<Rating> tmp;

            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Rating>));

            using (Stream fStream = File.OpenRead(path))
            {
                tmp = (List<Rating>)xmlFormat.Deserialize(fStream);
            }

            return tmp;
        }

        public void Session()
        {
            byte menu = 0;
            bool menu_checking = true;

            while (menu_checking)
            {
                if(user.isAdmin && user.inSession)
                {
                    Console.WriteLine(
                    "Make your choice \n" +
                    "1. Add test to base \n" +
                    "2. Add mixed test to base \n" +
                    "3. Edit test in base \n" +
                    "4. EXIT"
                    );

                    menu = Convert.ToByte(Console.ReadLine());

                    subject = new Subject();

                    switch (menu)
                    {
                        case 1:
                            subject.Tests_creating();
                            break;
                        case 2:
                            subject.Tests_mixing();
                            break;
                        case 3:
                            subject.Tests_editing();
                            break;
                        case 4:
                            user.inSession = false;
                            menu_checking = false;
                            break;
                        default:
                            Console.WriteLine("Wrong choice. Try again.");
                            break;
                    }
                }
                else if (user.inSession)
                {
                    Console.WriteLine(
                    "Make your choice \n" +
                    "1. Start new quiz \n" +
                    "2. Show my last results \n" +
                    "3. Show all users results \n" +
                    "4. Edit name surname patronymic \n" +
                    "5. Edit birthdate \n" +
                    "6. Edit password \n" +
                    "7. EXIT"
                    );

                    menu = Convert.ToByte(Console.ReadLine());

                    switch (menu)
                    {
                        case 1:
                            Start_quiz();
                            break;
                        case 2:
                            Special_rating();
                            break;
                        case 3:
                            General_rating();
                            break;
                        case 4:
                            user.Edit_nsp();
                            break;
                        case 5:
                            user.Edit_birthdate();
                            break;
                        case 6:
                            user.Edit_pass();
                            break;
                        case 7:
                            menu_checking = false;
                            break;
                        default:
                            Console.WriteLine("Wrong choice. Try again.");
                            break;
                    }
                }
                else
                {
                    user.inSession = false;
                    menu_checking = false;
                }
            }
        }

        public void Start_quiz()
        {
            subject = new Subject();

            #region Get_subject_list
            subject.Subjects = subject.FS_in();            

            Console.WriteLine("Here is the list of the current subjects");
            if (File.Exists("MIXED.xml"))
                Console.WriteLine("MIXED");

            foreach (var item in subject.Subjects)
                Console.WriteLine(item);
            #endregion

            Console.WriteLine("Enter the subject that you want quiz");
            string? tmp_subject = Console.ReadLine();
            if (tmp_subject != null)
                tmp_subject = tmp_subject.ToUpper();

            #region Get_test_list
            subject.Tests = subject.FS_in(tmp_subject);

            byte right_answers = 0;
            float gained_points = 0f;
            string? my_answer;

            for (int i = 0; i < subject.Tests.Length; i++)
            {
                Console.Write(subject.Tests[i].ToString());

                Console.Write("My answer is option -> ");
                my_answer = Console.ReadLine();
                my_answer = my_answer.ToUpper();
                my_answer = HashString(my_answer, "abc");

                if(my_answer.CompareTo(subject.Tests[i].Answer) == 0)
                {
                    right_answers++;
                    gained_points += subject.Tests[i].Score;
                }
            }

            Console.WriteLine("You have " + right_answers + " right answers and you have gained " + gained_points + " points. Check rating tables \n");
            #endregion

            string spec_rate_path = user.Login + "/" + tmp_subject + "_spe_rate.xml";
            string gene_rate_path = tmp_subject + "_gen_rate.xml";

            Rating tmp_rate = new Rating();
            tmp_rate.Login = user.Login;
            tmp_rate.NSP = user.NSP;
            tmp_rate.Result = gained_points;
            tmp_rate.Right = right_answers;
            tmp_rate.ExamDate = DateTime.Now;

            List<Rating> tmp_list  = new List<Rating>();

            if (File.Exists(spec_rate_path))
            {
                tmp_list = FS_in(spec_rate_path);
                tmp_list.Add(tmp_rate);
                special = tmp_list.OrderBy(x => x.Result).ToList();
                special.Reverse();
                for (int i = 0; i < special.Count; i++)
                    special[i].Rank = i + 1;
                FS_out(special, spec_rate_path);
            }
            else
            {
                special = new List<Rating>();
                special.Add(tmp_rate);
                FS_out(special, spec_rate_path);
            }

            tmp_list  = new List<Rating>();
            List<Rating> tmp_list2 = new List<Rating>();

            if (File.Exists(gene_rate_path))
            {
                tmp_list = FS_in(gene_rate_path);
                tmp_list.Add(tmp_rate);
                tmp_list2 = tmp_list.OrderBy(x => x.Result).ToList();
                tmp_list2.Reverse();
                for (int i = 0; i < tmp_list2.Count; i++)
                    tmp_list2[i].Rank = i + 1;

                general = new List<Rating>();

                if(tmp_list2.Count > 20)
                    for (int i = 0; i < 20; i++)
                        general[i] = tmp_list2[i];
                else
                    general = tmp_list2;

                FS_out(general, gene_rate_path);
            }
            else
            {
                general = new List<Rating>();
                general.Add(tmp_rate);
                FS_out(general, gene_rate_path);
            }
        }

        public void General_rating()
        {
            subject = new Subject();

            #region Get_subject_list
            subject.Subjects = subject.FS_in();

            Console.WriteLine("Here is the list of the current subjects");
            if (File.Exists("MIXED.xml"))
                Console.WriteLine("MIXED");

            foreach (var item in subject.Subjects)
                Console.WriteLine(item);
            #endregion

            Console.WriteLine("Enter the subject that you want get rating");
            string? tmp_subject = Console.ReadLine();
            if (tmp_subject != null)
                tmp_subject = tmp_subject.ToUpper();

            string gene_rate_path = tmp_subject + "_gen_rate.xml";

            if (File.Exists(gene_rate_path)) { 
                general = FS_in(gene_rate_path);
                Console.WriteLine("Rank" + "\t" + "Login" + "\t\t" + "Name Surname" + "\t\t" + "Points" + "\t\t" + "Answers" + "\t\t" + "Exam Date");
                foreach (var item in general)
                    Console.Write(item.ToString());
            }
            else
            {
                Console.WriteLine("There is no rating for this subject yet.");
            }
        }

        public void Special_rating()
        {
            subject = new Subject();

            #region Get_subject_list
            subject.Subjects = subject.FS_in();

            Console.WriteLine("Here is the list of the current subjects");
            if (File.Exists("MIXED.xml"))
                Console.WriteLine("MIXED");

            foreach (var item in subject.Subjects)
                Console.WriteLine(item);
            #endregion

            Console.WriteLine("Enter the subject that you want get rating");
            string? tmp_subject = Console.ReadLine();
            if (tmp_subject != null)
                tmp_subject = tmp_subject.ToUpper();

            string spec_rate_path = user.Login + "/" + tmp_subject + "_spe_rate.xml";

            if(File.Exists(spec_rate_path)) {
                special = FS_in(spec_rate_path);
                Console.WriteLine("Rank" + "\t" + "Login" + "\t\t" + "Name Surname" + "\t\t" + "Points" + "\t\t" + "Answers" + "\t\t" + "Exam Date");
                foreach (var item in special)
                    Console.Write(item.ToString());
            }
            else
            {
                Console.WriteLine("There is no rating for this subject yet.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            byte operation = 0;
            bool checking = true;

            Quiz quiz = new Quiz();
            quiz.user = new Users();

            while (checking)
            {
                Console.WriteLine(
                    "Make your choice \n" + 
                    "1. Login \n" +
                    "2. Registration \n" +
                    "3. Pass Recovery \n" +
                    "4. EXIT"
                    );

                operation = Convert.ToByte(Console.ReadLine());

                switch(operation)
                {
                    case 1:
                        quiz.user.Login_operation();
                        quiz.Session();
                        break;
                    case 2:
                        quiz.user.Registration();
                        break;
                    case 3:
                        quiz.user.Pass_recovery();
                        break;
                    case 4:
                        checking = false;
                        break;
                    default:
                        Console.WriteLine("Wrong choice. Try again.");
                        break;
                }
            }
        }
    }
}