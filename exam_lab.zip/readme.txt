for manipulating with utility

GOOD LUCK

Admin
-------------------
Login - 23c9knm
Password - cyber87!

Users
------------
Login - 111aa11
Password - 00000

Login - 222bb22
Password - 12345